import fs from "fs";
import path from "path";

const dbPath = path.join(process.cwd(), "data", "database.sqlite");

if (fs.existsSync(dbPath)) {
  fs.unlinkSync(dbPath);
  console.log("Deleted corrupted database file");
} else {
  console.log("Database file does not exist");
}
