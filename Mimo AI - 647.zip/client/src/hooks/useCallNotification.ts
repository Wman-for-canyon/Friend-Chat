import { useEffect, useRef, useState, useCallback } from "react";

interface UseCallNotificationConfig {
  enabled?: boolean;
}

export function useCallNotification({ enabled = true }: UseCallNotificationConfig = {}) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [volume, setVolume] = useState(0.5);
  const [isMuted, setIsMuted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  // Initialize audio element
  useEffect(() => {
    if (!audioRef.current) {
      const audio = new Audio();
      audio.loop = true;
      
      // Create a simple beeping notification sound using Web Audio API
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      // Generate a simple ringtone pattern (two tones)
      const generateTone = (frequency: number, duration: number) => {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.value = frequency;
        oscillator.type = "sine";
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + duration);
      };

      // Create ringtone pattern (alternating high-low tones)
      const playRingtone = () => {
        const now = audioContext.currentTime;
        generateTone(800, 0.2); // Higher tone
        setTimeout(() => generateTone(600, 0.2), 250); // Lower tone
      };

      audioRef.current = audio;
      
      // Store reference for playing the ringtone
      (audioRef.current as any).playRingtone = playRingtone;
    }
  }, []);

  const play = useCallback(() => {
    if (!enabled || isMuted) return;
    
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      // Create oscillators for the ringtone
      const playTone = (freq: number, duration: number, startTime: number) => {
        const osc = audioContext.createOscillator();
        const gain = audioContext.createGain();
        
        osc.connect(gain);
        gain.connect(audioContext.destination);
        
        osc.frequency.value = freq;
        osc.type = "sine";
        
        gain.gain.setValueAtTime(isMuted ? 0 : volume * 0.3, audioContext.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);
        
        osc.start(audioContext.currentTime + startTime);
        osc.stop(audioContext.currentTime + startTime + duration);
      };

      // Double pattern: high-low-high-low
      const pattern = [
        { freq: 800, delay: 0 },
        { freq: 600, delay: 0.25 },
        { freq: 800, delay: 0.5 },
        { freq: 600, delay: 0.75 },
      ];

      pattern.forEach(({ freq, delay }) => {
        playTone(freq, 0.2, delay);
      });

      setIsPlaying(true);
    } catch (error) {
      console.error("Failed to play notification sound:", error);
    }
  }, [enabled, isMuted, volume]);

  const stop = useCallback(() => {
    setIsPlaying(false);
  }, []);

  const toggleMute = useCallback(() => {
    setIsMuted((prev) => !prev);
  }, []);

  const setNotificationVolume = useCallback((newVolume: number) => {
    setVolume(Math.max(0, Math.min(1, newVolume)));
  }, []);

  return {
    play,
    stop,
    volume,
    setVolume: setNotificationVolume,
    isMuted,
    toggleMute,
    isPlaying,
  };
}
