import { useEffect, useRef, useState, useCallback } from "react";
import { io } from "socket.io-client";

interface WebRTCConfig {
  userId: number;
  remoteUserId: number;
  onRemoteStream: (stream: MediaStream) => void;
  onCallEnded: () => void;
}

export function useWebRTC({
  userId,
  remoteUserId,
  onRemoteStream,
  onCallEnded,
}: WebRTCConfig) {
  const socketRef = useRef<ReturnType<typeof io> | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [callInProgress, setCallInProgress] = useState(false);

  // Initialize WebSocket and WebRTC
  useEffect(() => {
    // Connect socket
    socketRef.current = io(window.location.origin);

    socketRef.current.on("connect", () => {
      console.log("Socket connected, registering user:", userId);
      socketRef.current?.emit("register-user", userId);
      setIsConnected(true);
    });

    socketRef.current.on("offer", async (data: { offer: RTCSessionDescriptionInit; from: string }) => {
      console.log("Received offer from:", data.from);
      if (!peerConnectionRef.current) {
        await initializePeerConnection();
      }

      const pc = peerConnectionRef.current;
      if (pc) {
        await pc.setRemoteDescription(new RTCSessionDescription(data.offer));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        socketRef.current?.emit("answer", {
          to: remoteUserId,
          answer: answer,
        });
      }
    });

    socketRef.current.on("answer", async (data: { answer: RTCSessionDescriptionInit; from: string }) => {
      console.log("Received answer from:", data.from);
      const pc = peerConnectionRef.current;
      if (pc && pc.signalingState !== "stable") {
        await pc.setRemoteDescription(new RTCSessionDescription(data.answer));
      }
    });

    socketRef.current.on("ice-candidate", (data: { candidate: RTCIceCandidate; from: string }) => {
      console.log("Received ICE candidate from:", data.from);
      const pc = peerConnectionRef.current;
      if (pc && data.candidate) {
        pc.addIceCandidate(new RTCIceCandidate(data.candidate)).catch((err) =>
          console.error("Failed to add ICE candidate:", err)
        );
      }
    });

    socketRef.current.on("call-ended", () => {
      console.log("Call ended by remote peer");
      closeConnection();
      onCallEnded();
    });

    return () => {
      socketRef.current?.disconnect();
    };
  }, [userId, remoteUserId]);

  const initializePeerConnection = useCallback(async () => {
    try {
      const pc = new RTCPeerConnection({
        iceServers: [
          { urls: ["stun:stun.l.google.com:19302"] },
          { urls: ["stun:stun1.l.google.com:19302"] },
        ],
      });

      pc.onicecandidate = (event) => {
        if (event.candidate) {
          socketRef.current?.emit("ice-candidate", {
            to: remoteUserId,
            candidate: event.candidate,
          });
        }
      };

      pc.ontrack = (event) => {
        console.log("Received remote track");
        onRemoteStream(event.streams[0]);
      };

      pc.onconnectionstatechange = () => {
        console.log("Connection state:", pc.connectionState);
        if (pc.connectionState === "disconnected" || pc.connectionState === "failed") {
          closeConnection();
          onCallEnded();
        }
      };

      peerConnectionRef.current = pc;
    } catch (error) {
      console.error("Failed to initialize peer connection:", error);
    }
  }, [remoteUserId]);

  const startCall = useCallback(async () => {
    try {
      if (!localStreamRef.current) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: { echoCancellation: true, noiseSuppression: true },
        });
        localStreamRef.current = stream;
      }

      if (!peerConnectionRef.current) {
        await initializePeerConnection();
      }

      const pc = peerConnectionRef.current;
      if (pc && localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((track) => {
          pc.addTrack(track, localStreamRef.current!);
        });

        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        socketRef.current?.emit("offer", {
          to: remoteUserId,
          offer: offer,
        });

        setCallInProgress(true);
      }
    } catch (error) {
      console.error("Failed to start call:", error);
    }
  }, [initializePeerConnection, remoteUserId]);

  const closeConnection = useCallback(() => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
    }

    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }

    setCallInProgress(false);
  }, []);

  const endCall = useCallback(() => {
    socketRef.current?.emit("end-call", { toUserId: remoteUserId });
    closeConnection();
  }, [remoteUserId, closeConnection]);

  const toggleAudio = useCallback((enabled: boolean) => {
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = enabled;
      });
    }
  }, []);

  const toggleVideo = useCallback((enabled: boolean) => {
    if (localStreamRef.current) {
      localStreamRef.current.getVideoTracks().forEach((track) => {
        track.enabled = enabled;
      });
    }
  }, []);

  return {
    localStream: localStreamRef.current,
    peerConnection: peerConnectionRef.current,
    isConnected,
    callInProgress,
    startCall,
    endCall,
    toggleAudio,
    toggleVideo,
  };
}
