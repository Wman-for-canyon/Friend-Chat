import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import ConversationList from "../components/ConversationList";
import ChatPanel from "../components/ChatPanel";
import CallInvitation from "../components/CallInvitation";
import NotificationBell from "../components/NotificationBell";
import { Video, Bell } from "lucide-react";
import { io } from "socket.io-client";
import { useCallNotification } from "../hooks/useCallNotification";

export default function HomePage() {
  const [conversations, setConversations] = useState<any[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [newUserSearch, setNewUserSearch] = useState("");
  const [incomingCall, setIncomingCall] = useState<{ fromUserId: number; callerName: string } | null>(null);
  const socketRef = useRef<ReturnType<typeof io> | null>(null);
  const navigate = useNavigate();

  const userId = localStorage.getItem("userId");
  const username = localStorage.getItem("username");

  useEffect(() => {
    if (!userId) {
      navigate("/");
      return;
    }

    fetchConversations();
    fetchUsers();
    setupSocket();

    return () => {
      socketRef.current?.disconnect();
    };
  }, [userId, navigate]);

  const setupSocket = () => {
    socketRef.current = io(window.location.origin);

    socketRef.current.on("connect", () => {
      console.log("Socket connected");
      socketRef.current?.emit("register-user", parseInt(userId!));
    });

    socketRef.current.on("incoming-call", (data: { fromUserId: number; fromSocketId: string }) => {
      console.log("Incoming call from:", data.fromUserId);
      const caller = users.find((u) => u.id === data.fromUserId);
      setIncomingCall({
        fromUserId: data.fromUserId,
        callerName: caller?.username || "Unknown User",
      });
    });

    socketRef.current.on("call-rejected", () => {
      console.log("Call rejected");
    });

    socketRef.current.on("disconnect", () => {
      console.log("Socket disconnected");
    });
  };

  const fetchConversations = async () => {
    try {
      console.log("Fetching conversations for userId:", userId);
      const response = await fetch(`/api/conversations?userId=${userId}`);
      if (response.ok) {
        const data = await response.json();
        console.log("Fetched conversations:", data);
        setConversations(data);
      } else {
        console.error("Failed to fetch conversations, status:", response.status);
      }
    } catch (error) {
      console.error("Failed to fetch conversations:", error);
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await fetch("/api/users");
      if (response.ok) {
        const data = await response.json();
        setUsers(data.filter((u: any) => u.id !== parseInt(userId!)));
      }
    } catch (error) {
      console.error("Failed to fetch users:", error);
    }
  };

  const handleStartConversation = async (otherUserId: number) => {
    try {
      const user1_id = parseInt(userId!);
      console.log("Starting conversation:", { user1_id, user2_id: otherUserId });
      const response = await fetch("/api/conversations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user1_id,
          user2_id: otherUserId,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        console.log("Conversation created:", data);
        setSelectedConversation(data.id);
        fetchConversations();
      } else {
        console.error("Failed to create conversation, status:", response.status);
      }
    } catch (error) {
      console.error("Failed to start conversation:", error);
    }
  };

  const handleStartCall = (otherUserId: number) => {
    navigate(`/call/${otherUserId}`);
  };

  const handleAcceptCall = () => {
    if (incomingCall) {
      setIncomingCall(null);
      navigate(`/call/${incomingCall.fromUserId}`);
    }
  };

  const handleRejectCall = () => {
    if (incomingCall) {
      socketRef.current?.emit("call-rejected", { toUserId: incomingCall.fromUserId });
      setIncomingCall(null);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("userId");
    localStorage.removeItem("username");
    navigate("/");
  };

  const handleDeleteAccount = async () => {
    if (!window.confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
      return;
    }

    try {
      const response = await fetch("/api/auth/account", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: parseInt(userId!) }),
      });

      if (response.ok) {
        localStorage.removeItem("userId");
        localStorage.removeItem("username");
        navigate("/");
      } else {
        alert("Failed to delete account");
      }
    } catch (error) {
      console.error("Failed to delete account:", error);
      alert("Failed to delete account");
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-black">
      {incomingCall && (
        <CallInvitation
          callerName={incomingCall.callerName}
          onAccept={handleAcceptCall}
          onReject={handleRejectCall}
        />
      )}

      <div className="flex h-screen">
        <div className="w-80 border-r border-gray-300 dark:border-gray-700 bg-white dark:bg-black flex flex-col">
          <div className="p-4 border-b border-gray-300 dark:border-gray-700">
            <div className="flex justify-between items-center mb-4">
              <h1 className="text-2xl font-bold text-black dark:text-white">Messages</h1>
              <div className="flex gap-2">
                <Button
                  onClick={handleLogout}
                  variant="ghost"
                  size="sm"
                  className="text-xs text-gray-600 dark:text-gray-400 hover:text-black dark:hover:text-white"
                >
                  Logout
                </Button>
                <Button
                  onClick={handleDeleteAccount}
                  variant="ghost"
                  size="sm"
                  className="text-xs text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300"
                >
                  Delete Account
                </Button>
              </div>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">{username}</p>
          </div>

          <div className="p-4 border-b border-gray-300 dark:border-gray-700">
            <Input
              type="text"
              placeholder="Search users..."
              value={newUserSearch}
              onChange={(e) => setNewUserSearch(e.target.value)}
              className="bg-gray-50 dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-black dark:text-white placeholder:text-gray-500 dark:placeholder:text-gray-400"
            />
            <div className="mt-3 space-y-2 max-h-40 overflow-y-auto">
              {users
                .filter((u) =>
                  u.username.toLowerCase().includes(newUserSearch.toLowerCase())
                )
                .map((u) => (
                  <div
                    key={u.id}
                    className="flex items-center gap-2 px-3 py-2 rounded bg-gray-100 dark:bg-gray-900 hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors"
                  >
                    <button
                      onClick={() => handleStartConversation(u.id)}
                      className="flex-1 text-left text-black dark:text-white text-sm font-medium"
                    >
                      {u.username}
                    </button>
                    <Button
                      onClick={() => handleStartCall(u.id)}
                      size="sm"
                      variant="ghost"
                      className="p-1 h-auto bg-black dark:bg-white hover:bg-gray-800 dark:hover:bg-gray-200 text-white dark:text-black"
                    >
                      <Video className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
            </div>
          </div>

          <ConversationList
            conversations={conversations}
            selectedConversation={selectedConversation}
            onSelectConversation={setSelectedConversation}
          />
        </div>

        <div className="flex-1 flex flex-col bg-gray-50 dark:bg-black border-l border-gray-300 dark:border-gray-700">
          {selectedConversation ? (
            <ChatPanel conversationId={selectedConversation} currentUserId={parseInt(userId!)} />
          ) : (
            <div className="flex-1 flex items-center justify-center text-gray-400">
              <p>Select a conversation to start messaging</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
