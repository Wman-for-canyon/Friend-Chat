import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "../components/ui/button";
import CallControls from "../components/CallControls";
import { useWebRTC } from "../hooks/useWebRTC";

export default function VideoCallPage() {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  const currentUserId = parseInt(localStorage.getItem("userId") || "0");
  const remoteUserId = parseInt(userId || "0");

  const {
    localStream,
    callInProgress,
    isConnected,
    startCall,
    endCall: webrtcEndCall,
    toggleAudio: webrtcToggleAudio,
    toggleVideo: webrtcToggleVideo,
  } = useWebRTC({
    userId: currentUserId,
    remoteUserId,
    onRemoteStream: setRemoteStream,
    onCallEnded: () => {
      navigate("/home");
    },
  });

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  useEffect(() => {
    if (isConnected && !callInProgress) {
      startCall();
    }
  }, [isConnected, callInProgress]);

  const handleToggleVideo = () => {
    webrtcToggleVideo(!videoEnabled);
    setVideoEnabled(!videoEnabled);
  };

  const handleToggleAudio = () => {
    webrtcToggleAudio(!audioEnabled);
    setAudioEnabled(!audioEnabled);
  };

  const handleEndCall = () => {
    webrtcEndCall();
    navigate("/home");
  };

  return (
    <div className="min-h-screen bg-black flex flex-col">
      {/* Video Container */}
      <div className="flex-1 flex gap-4 p-4 relative">
        {/* Remote Video */}
        <div className="flex-1 relative bg-black rounded-lg overflow-hidden border-2 border-gray-800">
          {remoteStream ? (
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-400">
              <p>Waiting for connection...</p>
            </div>
          )}
        </div>

        {/* Local Video */}
        <div className="w-48 h-40 absolute bottom-20 right-4 bg-black rounded-lg overflow-hidden border-2 border-gray-800">
          <video
            ref={localVideoRef}
            autoPlay
            muted
            playsInline
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Controls */}
      <CallControls
        videoEnabled={videoEnabled}
        audioEnabled={audioEnabled}
        onToggleVideo={handleToggleVideo}
        onToggleAudio={handleToggleAudio}
        onEndCall={handleEndCall}
      />
    </div>
  );
}
