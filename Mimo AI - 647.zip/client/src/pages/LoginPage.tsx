import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async () => {
    if (!username.trim()) return;

    setLoading(true);
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username }),
      });

      if (response.ok) {
        const data = await response.json();
        localStorage.setItem("userId", data.userId);
        localStorage.setItem("username", data.username);
        navigate("/home");
      }
    } catch (error) {
      console.error("Login failed:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-black flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-2 text-black dark:text-white">
            Connect
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Video and text messaging
          </p>
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <Label
              htmlFor="username"
              className="text-black dark:text-white text-sm font-medium"
            >
              Username
            </Label>
            <Input
              id="username"
              type="text"
              placeholder="Enter your username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleLogin()}
              className="bg-gray-50 dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-black dark:text-white placeholder:text-gray-500 dark:placeholder:text-gray-400"
            />
          </div>

          <Button
            onClick={handleLogin}
            disabled={loading || !username.trim()}
            className="w-full bg-black dark:bg-white text-white dark:text-black hover:bg-gray-800 dark:hover:bg-gray-200 font-semibold"
          >
            {loading ? "Signing in..." : "Sign in"}
          </Button>
        </div>

        <p className="text-center text-sm text-gray-600 dark:text-gray-400">
          Create a new account by entering a unique username
        </p>
      </div>
    </div>
  );
}
