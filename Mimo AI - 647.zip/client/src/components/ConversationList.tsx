import { Card } from "./ui/card";

interface Conversation {
  id: number;
  otherUserName: string;
  otherUserId: number;
  lastMessage?: string;
  lastMessageTime?: string;
}

interface Props {
  conversations: Conversation[];
  selectedConversation: number | null;
  onSelectConversation: (id: number) => void;
}

export default function ConversationList({
  conversations,
  selectedConversation,
  onSelectConversation,
}: Props) {
  if (conversations.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center text-gray-500 dark:text-gray-400 p-4">
        <p className="text-center">No conversations yet. Start a new one!</p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto">
      {conversations.map((conversation) => (
        <button
          key={conversation.id}
          onClick={() => onSelectConversation(conversation.id)}
          className={`w-full p-4 border-b border-gray-300 dark:border-gray-700 text-left transition-colors ${
            selectedConversation === conversation.id
              ? "bg-gray-200 dark:bg-gray-800"
              : "hover:bg-gray-100 dark:hover:bg-gray-900"
          }`}
        >
          <h3 className="font-semibold text-black dark:text-white truncate">
            {conversation.otherUserName}
          </h3>
          {conversation.lastMessage && (
            <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
              {conversation.lastMessage}
            </p>
          )}
        </button>
      ))}
    </div>
  );
}
