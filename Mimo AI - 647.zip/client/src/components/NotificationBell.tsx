import { Bell, Volume2, VolumeX } from "lucide-react";
import { Button } from "./ui/button";

interface Props {
  isRinging: boolean;
  isMuted: boolean;
  volume: number;
  onMuteToggle: () => void;
  onVolumeChange: (volume: number) => void;
}

export default function NotificationBell({
  isRinging,
  isMuted,
  volume,
  onMuteToggle,
  onVolumeChange,
}: Props) {
  return (
    <div className="flex items-center gap-3 px-4 py-3 bg-gray-900 rounded-lg border border-gray-800">
      {/* Animated Bell Icon */}
      <div className={`relative ${isRinging ? "animate-bounce" : ""}`}>
        <Bell
          className={`w-6 h-6 transition-colors ${
            isRinging ? "text-white fill-white" : "text-gray-400"
          }`}
        />
        {isRinging && (
          <>
            <div className="absolute inset-0 rounded-full border-2 border-white opacity-75 animate-ping" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-600 rounded-full animate-pulse" />
          </>
        )}
      </div>

      {/* Mute Button */}
      <Button
        onClick={onMuteToggle}
        className="p-2 h-auto bg-transparent hover:bg-gray-800 border border-gray-700"
        title={isMuted ? "Unmute notifications" : "Mute notifications"}
      >
        {isMuted ? (
          <VolumeX className="w-5 h-5 text-gray-400" />
        ) : (
          <Volume2 className="w-5 h-5 text-white" />
        )}
      </Button>

      {/* Volume Control */}
      {!isMuted && (
        <input
          type="range"
          min="0"
          max="100"
          value={volume * 100}
          onChange={(e) => onVolumeChange(parseInt(e.target.value) / 100)}
          className="w-24 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-white"
          title={`Volume: ${Math.round(volume * 100)}%`}
        />
      )}

      {/* Volume Percentage */}
      <span className="text-sm text-gray-400 min-w-[40px]">
        {Math.round(volume * 100)}%
      </span>
    </div>
  );
}
