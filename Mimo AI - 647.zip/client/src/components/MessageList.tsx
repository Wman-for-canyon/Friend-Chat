interface Message {
  id: number;
  senderId: number;
  content: string;
  createdAt: string;
}

interface Props {
  messages: Message[];
  currentUserId: number;
}

export default function MessageList({ messages, currentUserId }: Props) {
  return (
    <div className="space-y-3">
      {messages.map((message) => (
        <div
          key={message.id}
          className={`flex ${
            message.senderId === currentUserId ? "justify-end" : "justify-start"
          }`}
        >
          <div
            className={`max-w-xs px-4 py-2 rounded-lg ${
              message.senderId === currentUserId
                ? "bg-black dark:bg-white text-white dark:text-black"
                : "bg-gray-200 dark:bg-gray-800 text-black dark:text-white"
            }`}
          >
            <p className="text-sm break-words">{message.content}</p>
            <p
              className={`text-xs mt-1 ${
                message.senderId === currentUserId
                  ? "text-gray-300 dark:text-gray-600"
                  : "text-gray-600 dark:text-gray-400"
              }`}
            >
              {new Date(message.createdAt).toLocaleTimeString()}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}
