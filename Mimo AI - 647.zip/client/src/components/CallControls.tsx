import { Button } from "./ui/button";
import { Mic, MicOff, Video, VideoOff, Phone, PhoneOff } from "lucide-react";

interface Props {
  videoEnabled: boolean;
  audioEnabled: boolean;
  onToggleVideo: () => void;
  onToggleAudio: () => void;
  onEndCall: () => void;
}

export default function CallControls({
  videoEnabled,
  audioEnabled,
  onToggleVideo,
  onToggleAudio,
  onEndCall,
}: Props) {
  return (
    <div className="bg-black border-t border-gray-800 p-4 flex justify-center gap-4">
      <Button
        onClick={onToggleVideo}
        variant="ghost"
        size="lg"
        className={`rounded-full w-16 h-16 p-0 ${
          videoEnabled
            ? "bg-gray-800 hover:bg-gray-700 text-white"
            : "bg-red-600 hover:bg-red-700 text-white"
        }`}
      >
        {videoEnabled ? (
          <Video className="w-6 h-6" />
        ) : (
          <VideoOff className="w-6 h-6" />
        )}
      </Button>

      <Button
        onClick={onToggleAudio}
        variant="ghost"
        size="lg"
        className={`rounded-full w-16 h-16 p-0 ${
          audioEnabled
            ? "bg-gray-800 hover:bg-gray-700 text-white"
            : "bg-red-600 hover:bg-red-700 text-white"
        }`}
      >
        {audioEnabled ? (
          <Mic className="w-6 h-6" />
        ) : (
          <MicOff className="w-6 h-6" />
        )}
      </Button>

      <Button
        onClick={onEndCall}
        size="lg"
        className="rounded-full w-16 h-16 p-0 bg-red-700 hover:bg-red-800 text-white"
      >
        <PhoneOff className="w-6 h-6" />
      </Button>
    </div>
  );
}
