import { useEffect } from "react";
import { Button } from "./ui/button";
import { Phone, PhoneOff, Bell } from "lucide-react";
import { useCallNotification } from "../hooks/useCallNotification";

interface Props {
  callerName: string;
  onAccept: () => void;
  onReject: () => void;
}

export default function CallInvitation({
  callerName,
  onAccept,
  onReject,
}: Props) {
  const { play, stop, isMuted, toggleMute, volume, setVolume } =
    useCallNotification({ enabled: true });

  // Play notification sound when component mounts
  useEffect(() => {
    play();
    return () => {
      stop();
    };
  }, [play, stop]);

  const handleAccept = () => {
    stop();
    onAccept();
  };

  const handleReject = () => {
    stop();
    onReject();
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
      <div className="bg-black border-2 border-white rounded-lg p-8 max-w-sm w-full mx-4 shadow-2xl">
        {/* Animated Bell Icon */}
        <div className="flex justify-center mb-4">
          <div className="relative">
            <Bell className="w-12 h-12 text-white fill-white animate-bounce" />
            <div className="absolute -top-2 -right-2 w-4 h-4 bg-red-600 rounded-full animate-pulse" />
          </div>
        </div>

        <h2 className="text-2xl font-bold text-white text-center mb-2">
          Incoming Call
        </h2>
        <p className="text-gray-300 text-center text-lg mb-6">
          {callerName} is calling...
        </p>

        {/* Notification Controls */}
        <div className="bg-gray-900 rounded-lg p-3 mb-6 flex items-center gap-3">
          <button
            onClick={toggleMute}
            className="p-2 hover:bg-gray-800 rounded transition-colors"
            title={isMuted ? "Unmute" : "Mute"}
          >
            {isMuted ? (
              <span className="text-sm text-gray-400">🔇</span>
            ) : (
              <span className="text-sm text-white">🔊</span>
            )}
          </button>
          <input
            type="range"
            min="0"
            max="100"
            value={volume * 100}
            onChange={(e) => setVolume(parseInt(e.target.value) / 100)}
            className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-white"
            disabled={isMuted}
          />
          <span className="text-xs text-gray-400 min-w-[30px]">
            {Math.round(volume * 100)}%
          </span>
        </div>

        <div className="flex gap-4 justify-center">
          <Button
            onClick={handleAccept}
            className="w-16 h-16 rounded-full bg-green-600 hover:bg-green-700 text-white flex items-center justify-center p-0"
          >
            <Phone className="w-6 h-6" />
          </Button>
          <Button
            onClick={handleReject}
            className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center p-0"
          >
            <PhoneOff className="w-6 h-6" />
          </Button>
        </div>
      </div>
    </div>
  );
}
