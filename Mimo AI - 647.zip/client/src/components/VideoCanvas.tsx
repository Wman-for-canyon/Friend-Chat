import { useRef, useEffect } from "react";

interface Props {
  stream: MediaStream | null;
  isMuted?: boolean;
  isLocal?: boolean;
}

export default function VideoCanvas({
  stream,
  isMuted = false,
  isLocal = false,
}: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  return (
    <video
      ref={videoRef}
      autoPlay
      muted={isMuted}
      playsInline
      className="w-full h-full object-cover"
    />
  );
}
