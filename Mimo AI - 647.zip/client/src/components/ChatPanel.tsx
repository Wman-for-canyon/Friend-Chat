import { useState, useEffect, useRef } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import MessageList from "./MessageList";

interface Props {
  conversationId: number;
  currentUserId: number;
}

export default function ChatPanel({ conversationId, currentUserId }: Props) {
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    console.log("ChatPanel mounted/updated with conversationId:", conversationId);
    setLoading(true);
    fetchMessages();
    const interval = setInterval(fetchMessages, 1000);
    return () => clearInterval(interval);
  }, [conversationId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const fetchMessages = async () => {
    try {
      const response = await fetch(
        `/api/messages?conversationId=${conversationId}`
      );
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
      }
    } catch (error) {
      console.error("Failed to fetch messages:", error);
    } finally {
      setLoading(false);
    }
  };

   const handleSendMessage = async (e: React.FormEvent) => {
     e.preventDefault();
     if (!input.trim()) return;

     const messageContent = input;
     setInput("");

     try {
       console.log("Sending message:", { conversationId, currentUserId, messageContent });
       const response = await fetch("/api/messages", {
         method: "POST",
         headers: { "Content-Type": "application/json" },
         body: JSON.stringify({
           conversationId,
           senderId: currentUserId,
           content: messageContent,
         }),
       });

       const responseData = await response.json();
       console.log("Message response:", { status: response.status, data: responseData });

       if (response.ok) {
         console.log("Message sent successfully, fetching updated messages");
         await fetchMessages();
       } else {
         console.error("Failed to send message:", responseData);
         setInput(messageContent);
       }
     } catch (error) {
       console.error("Failed to send message:", error);
       setInput(messageContent);
     }
   };

  return (
    <div className="flex flex-col h-full">
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 bg-white dark:bg-black">
        {loading ? (
          <div className="flex items-center justify-center h-full text-gray-500">
            Loading messages...
          </div>
        ) : (
          <>
            <MessageList
              messages={messages}
              currentUserId={currentUserId}
            />
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Input Area */}
      <form
        onSubmit={handleSendMessage}
        className="border-t border-gray-300 dark:border-gray-700 p-4 bg-white dark:bg-black flex gap-2"
      >
        <Input
          type="text"
          placeholder="Type a message..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="bg-gray-50 dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-black dark:text-white placeholder:text-gray-500 dark:placeholder:text-gray-400"
        />
        <Button
          type="submit"
          disabled={!input.trim()}
          className="bg-black dark:bg-white text-white dark:text-black hover:bg-gray-800 dark:hover:bg-gray-200 font-semibold min-w-fit"
        >
          Send
        </Button>
      </form>
    </div>
  );
}
