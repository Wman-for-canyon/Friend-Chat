import express from "express";
import dotenv from "dotenv";
import { setupStaticServing } from "./static-serve.js";
import { initializeDatabase, db } from "./database.js";
import authRouter from "./routes/auth.js";
import conversationRouter from "./routes/conversations.js";
import messageRouter from "./routes/messages.js";
import usersRouter from "./routes/users.js";
import callRouter from "./routes/calls.js";
import http from "http";
import { Server as SocketIOServer } from "socket.io";

dotenv.config();

const app = express();
const httpServer = http.createServer(app);
export const io = new SocketIOServer(httpServer, {
  cors: { origin: "*" },
});

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Initialize database
initializeDatabase();

// API Routes
app.use("/api/auth", authRouter);
app.use("/api/conversations", conversationRouter);
app.use("/api/messages", messageRouter);
app.use("/api/users", usersRouter);
app.use("/api/calls", callRouter);

// WebSocket handlers
io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("register-user", (userId: number) => {
    socket.join(`user-${userId}`);
    console.log("User registered:", userId, "Socket ID:", socket.id);
  });

  socket.on("initiate-call", (data: { fromUserId: number; toUserId: number }) => {
    console.log(`Call initiated from ${data.fromUserId} to ${data.toUserId}`);
    io.to(`user-${data.toUserId}`).emit("incoming-call", {
      fromUserId: data.fromUserId,
      fromSocketId: socket.id,
    });
  });

  socket.on("call-accepted", (data: { toUserId: number }) => {
    console.log(`Call accepted to user ${data.toUserId}`);
    io.to(`user-${data.toUserId}`).emit("call-accepted", {
      fromSocketId: socket.id,
    });
  });

  socket.on("call-rejected", (data: { toUserId: number }) => {
    console.log(`Call rejected to user ${data.toUserId}`);
    io.to(`user-${data.toUserId}`).emit("call-rejected", {});
  });

  socket.on("offer", (data: { to: number; offer: RTCSessionDescriptionInit }) => {
    console.log(`SDP Offer sent from ${socket.id}`);
    io.to(`user-${data.to}`).emit("offer", {
      offer: data.offer,
      from: socket.id,
    });
  });

  socket.on("answer", (data: { to: number; answer: RTCSessionDescriptionInit }) => {
    console.log(`SDP Answer sent from ${socket.id}`);
    io.to(`user-${data.to}`).emit("answer", {
      answer: data.answer,
      from: socket.id,
    });
  });

  socket.on("ice-candidate", (data: { to: number; candidate: RTCIceCandidate }) => {
    io.to(`user-${data.to}`).emit("ice-candidate", {
      candidate: data.candidate,
      from: socket.id,
    });
  });

  socket.on("end-call", (data: { toUserId: number }) => {
    console.log(`Call ended from ${socket.id}`);
    io.to(`user-${data.toUserId}`).emit("call-ended", {});
  });

  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
  });
});

// Export a function to start the server
export async function startServer(port: string | number) {
  try {
    if (process.env.NODE_ENV === "production") {
      setupStaticServing(app);
    }
    httpServer.listen(port, () => {
      console.log(`API Server running on port ${port}`);
    });
  } catch (err) {
    console.error("Failed to start server:", err);
    process.exit(1);
  }
}

// Start the server directly if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log("Starting server...");
  startServer(process.env.PORT || 3001);
}
