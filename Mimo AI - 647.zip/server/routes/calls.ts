import { Router, Request, Response } from "express";
import { db } from "../database.js";

const router = Router();

router.post("/initiate", async (req: Request, res: Response): Promise<void> => {
  try {
    const { fromUserId, toUserId } = req.body;

    if (!fromUserId || !toUserId) {
      res.status(400).json({ error: "fromUserId and toUserId are required" });
      return;
    }

    console.log(`Call initiated from ${fromUserId} to ${toUserId}`);
    res.json({ status: "initiated" });
  } catch (error) {
    console.error("Initiate call error:", error);
    res.status(500).json({ error: "Failed to initiate call" });
  }
});

export default router;
