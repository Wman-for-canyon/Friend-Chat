import { Router, Request, Response } from "express";
import { db } from "../database.js";

const router = Router();

router.post("/login", async (req: Request, res: Response): Promise<void> => {
  try {
    const { username } = req.body;

    if (!username || typeof username !== "string") {
      res.status(400).json({ error: "Username is required" });
      return;
    }

    let user = await db
      .selectFrom("users")
      .selectAll()
      .where("username", "=", username)
      .executeTakeFirst();

    if (!user) {
      const result = await db
        .insertInto("users")
        .values({ username, createdAt: new Date().toISOString() })
        .executeTakeFirstOrThrow();

      user = {
        id: Number(result.insertId),
        username,
        createdAt: new Date().toISOString(),
      };
    }

    res.json({ userId: user.id, username: user.username });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Login failed" });
  }
});

router.delete("/account", async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId } = req.body;

    if (!userId || typeof userId !== "number") {
      res.status(400).json({ error: "User ID is required" });
      return;
    }

    // Get all conversations involving this user
    const userConversations = await db
      .selectFrom("conversations")
      .select("id")
      .where((eb) =>
        eb.or([
          eb("user1_id", "=", userId),
          eb("user2_id", "=", userId),
        ])
      )
      .execute();

    const conversationIds = userConversations.map(c => c.id);

    // Delete all messages in those conversations
    if (conversationIds.length > 0) {
      await db
        .deleteFrom("messages")
        .where("conversationId", "in", conversationIds)
        .execute();
    }

    // Delete all conversations involving this user
    await db
      .deleteFrom("conversations")
      .where((eb) =>
        eb.or([
          eb("user1_id", "=", userId),
          eb("user2_id", "=", userId),
        ])
      )
      .execute();

    // Delete the user
    await db
      .deleteFrom("users")
      .where("id", "=", userId)
      .execute();

    res.json({ success: true });
  } catch (error) {
    console.error("Account deletion error:", error);
    res.status(500).json({ error: "Failed to delete account" });
  }
});

export default router;
