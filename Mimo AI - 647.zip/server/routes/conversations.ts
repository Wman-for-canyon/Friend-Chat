import { Router, Request, Response } from "express";
import { db } from "../database.js";

const router = Router();

router.get("/", async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId } = req.query;

    if (!userId) {
      console.error("GET /conversations: userId is required");
      res.status(400).json({ error: "userId is required" });
      return;
    }

    const userIdNum = Number(userId);
    console.log("GET /conversations for userId:", userIdNum);

    const conversations = await db
      .selectFrom("conversations")
      .leftJoin("users as user1", "conversations.user1_id", "user1.id")
      .leftJoin("users as user2", "conversations.user2_id", "user2.id")
      .select([
        "conversations.id",
        "conversations.user1_id",
        "conversations.user2_id",
        "conversations.createdAt",
        "user1.username as user1_username",
        "user2.username as user2_username",
      ])
      .where((eb) =>
        eb.or([
          eb("conversations.user1_id", "=", userIdNum),
          eb("conversations.user2_id", "=", userIdNum),
        ])
      )
      .execute();

    console.log("Found conversations:", conversations.length);

    const formattedConversations = conversations.map((conv: any) => {
      const otherUserId =
        conv.user1_id === userIdNum ? conv.user2_id : conv.user1_id;
      const otherUserName =
        conv.user1_id === userIdNum
          ? conv.user2_username
          : conv.user1_username;

      return {
        id: conv.id,
        otherUserId,
        otherUserName: otherUserName || "Unknown",
      };
    });

    console.log("Returning formatted conversations:", formattedConversations);
    res.json(formattedConversations);
  } catch (error) {
    console.error("Get conversations error:", error);
    res.status(500).json({ error: "Failed to fetch conversations" });
  }
});

router.post("/", async (req: Request, res: Response): Promise<void> => {
  try {
    const { user1_id, user2_id } = req.body;

    if (!user1_id || !user2_id) {
      res.status(400).json({ error: "user1_id and user2_id are required" });
      return;
    }

    let conversation = await db
      .selectFrom("conversations")
      .selectAll()
      .where((eb) =>
        eb.or([
          eb.and([
            eb("user1_id", "=", user1_id),
            eb("user2_id", "=", user2_id),
          ]),
          eb.and([
            eb("user1_id", "=", user2_id),
            eb("user2_id", "=", user1_id),
          ]),
        ])
      )
      .executeTakeFirst();

    if (!conversation) {
      const result = await db
        .insertInto("conversations")
        .values({
          user1_id: Math.min(user1_id, user2_id),
          user2_id: Math.max(user1_id, user2_id),
        })
        .executeTakeFirstOrThrow();

      conversation = {
        id: Number(result.insertId),
        user1_id: Math.min(user1_id, user2_id),
        user2_id: Math.max(user1_id, user2_id),
        createdAt: new Date().toISOString(),
      };
    }

    res.json(conversation);
  } catch (error) {
    console.error("Create conversation error:", error);
    res.status(500).json({ error: "Failed to create conversation" });
  }
});

export default router;
