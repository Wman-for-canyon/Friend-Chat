import { Router, Request, Response } from "express";
import { db } from "../database.js";

const router = Router();

router.get("/", async (req: Request, res: Response): Promise<void> => {
  try {
    const { conversationId } = req.query;

    if (!conversationId) {
      console.error("GET /messages: conversationId is required");
      res.status(400).json({ error: "conversationId is required" });
      return;
    }

    console.log("GET /messages for conversationId:", conversationId);

    const messages = await db
      .selectFrom("messages")
      .selectAll()
      .where("conversationId", "=", Number(conversationId))
      .orderBy("createdAt", "asc")
      .execute();

    console.log("Found messages:", messages.length);
    res.json(messages);
  } catch (error) {
    console.error("Get messages error:", error);
    res.status(500).json({ error: "Failed to fetch messages" });
  }
});

router.post("/", async (req: Request, res: Response): Promise<void> => {
  try {
    const { conversationId, senderId, content } = req.body;

    console.log("POST /messages:", { conversationId, senderId, content });

    if (!conversationId || !senderId || !content) {
      console.error("Missing required fields:", { conversationId, senderId, content });
      res
        .status(400)
        .json({
          error: "conversationId, senderId, and content are required",
        });
      return;
    }

    const result = await db
      .insertInto("messages")
      .values({
        conversationId: Number(conversationId),
        senderId: Number(senderId),
        content,
      })
      .executeTakeFirstOrThrow();

    console.log("Message inserted:", { insertId: result.insertId });

    const message = {
      id: Number(result.insertId),
      conversationId,
      senderId,
      content,
      createdAt: new Date().toISOString(),
    };

    console.log("Returning message:", message);
    res.json(message);
  } catch (error) {
    console.error("Create message error:", error);
    res.status(500).json({ error: "Failed to send message" });
  }
});

export default router;
