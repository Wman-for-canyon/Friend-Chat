import { Router, Request, Response } from "express";
import { db } from "../database.js";

const router = Router();

router.get("/", async (req: Request, res: Response): Promise<void> => {
  try {
    const users = await db.selectFrom("users").selectAll().execute();
    console.log("GET /users returned:", users.length, "users");
    res.json(users);
  } catch (error) {
    console.error("Get users error:", error);
    res.status(500).json({ error: "Failed to fetch users" });
  }
});

export default router;
