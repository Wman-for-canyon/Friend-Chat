import { Kysely, SqliteDialect } from "kysely";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface DatabaseSchema {
  users: {
    id: number;
    username: string;
    createdAt: string;
  };
  conversations: {
    id: number;
    user1_id: number;
    user2_id: number;
    createdAt: string;
  };
  messages: {
    id: number;
    conversationId: number;
    senderId: number;
    content: string;
    createdAt: string;
  };
}

const dbPath = path.join(__dirname, "../data/database.sqlite");

// Ensure data directory exists
const dataDir = path.dirname(dbPath);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
  console.log("Created data directory:", dataDir);
}

// Remove corrupted database file if it exists
if (fs.existsSync(dbPath)) {
  try {
    const sqliteDb = new Database(dbPath);
    sqliteDb.prepare("SELECT 1").get();
    sqliteDb.close();
    console.log("Existing database is valid");
  } catch (error) {
    console.log("Database file is corrupted, removing it...");
    fs.unlinkSync(dbPath);
  }
}

const sqliteDb = new Database(dbPath);

export const db = new Kysely<DatabaseSchema>({
  dialect: new SqliteDialect({ database: sqliteDb }),
  log: ["query", "error"],
});

export function initializeDatabase() {
  console.log("Database initialized at:", dbPath);
  
  // Create tables
  sqliteDb.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      createdAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS conversations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user1_id INTEGER NOT NULL,
      user2_id INTEGER NOT NULL,
      createdAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user1_id) REFERENCES users(id),
      FOREIGN KEY (user2_id) REFERENCES users(id),
      UNIQUE(user1_id, user2_id)
    );

    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      conversationId INTEGER NOT NULL,
      senderId INTEGER NOT NULL,
      content TEXT NOT NULL,
      createdAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (conversationId) REFERENCES conversations(id),
      FOREIGN KEY (senderId) REFERENCES users(id)
    );

    CREATE INDEX IF NOT EXISTS idx_conversations_user1 ON conversations(user1_id);
    CREATE INDEX IF NOT EXISTS idx_conversations_user2 ON conversations(user2_id);
    CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversationId);
    CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(senderId);
  `);

  // Insert sample users
  const userCount = sqliteDb.prepare("SELECT COUNT(*) as count FROM users").get() as { count: number };
  if (userCount.count === 0) {
    console.log("Inserting sample users...");
    sqliteDb.prepare("INSERT INTO users (username) VALUES (?)").run("Alice");
    sqliteDb.prepare("INSERT INTO users (username) VALUES (?)").run("Bob");
    sqliteDb.prepare("INSERT INTO users (username) VALUES (?)").run("Charlie");
    console.log("Sample users created");
  }
}
