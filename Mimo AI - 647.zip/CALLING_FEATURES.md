# Video & Voice Calling Features

## Overview
This application implements a complete peer-to-peer video and voice calling system using WebRTC with Socket.IO signaling, combined with text messaging functionality. The UI uses a clean black and white design for a modern, minimal aesthetic.

## Key Features

### WebRTC Peer-to-Peer Communication
- **Real-time video and audio** transmission using WebRTC
- **SDP Offer/Answer exchange** for connection establishment
- **ICE candidate handling** for optimal network path discovery
- **Automatic connection management** with fallback STUN servers
- **Audio processing** with echo cancellation and noise suppression

### Socket.IO Signaling
- **Real-time signaling** for call initiation and management
- **User registration** - users register their socket ID on connection
- **Call negotiation** - SDP offers and answers exchanged through WebSocket
- **ICE candidate relay** - NAT traversal through ICE candidates
- **Call state management** - accept, reject, and end call signals

### Call Features
- **Video toggle** - users can enable/disable their camera during calls
- **Audio toggle** - users can mute/unmute microphone during calls
- **Incoming call notifications** - modal popup showing incoming caller
- **Call acceptance/rejection** - users can respond to incoming calls
- **Call termination** - clean connection closure with proper cleanup

### User Interface
- **Black & White Theme** - minimalist design with high contrast
- **Call Controls** - large, easy-to-tap buttons for video/audio/end
- **Picture-in-Picture** - local video in corner, remote video fullscreen
- **User List** - all registered users with quick video call buttons
- **Conversation Panel** - integrated messaging during active messaging sessions
- **Call Invitation Modal** - clear incoming call notifications

### Messaging Features
- **Text messaging** - send/receive messages in conversations
- **Conversation management** - create or select existing conversations
- **Message history** - persistent storage of all messages
- **Real-time updates** - polling for new messages (can be upgraded to WebSocket)
- **User search** - find and initiate conversations with other users

## Architecture

### Frontend
- `useWebRTC` hook manages WebRTC peer connection lifecycle
- Socket.IO client handles signaling and incoming call notifications
- React components for UI with Tailwind CSS styling
- Video refs for local/remote stream management

### Backend
- Express.js server with Socket.IO integration
- SQLite database for persistent data (users, conversations, messages)
- REST API for data operations
- WebSocket namespace for real-time call signaling

### Database Schema
- **users** - stores user accounts (username, ID)
- **conversations** - stores conversation pairs between users
- **messages** - stores text messages within conversations

## WebRTC Flow

### Initiating a Call
1. User clicks video call button for another user
2. Navigate to `/call/:userId` page
3. WebRTC peer connection initialized
4. Local media stream requested (audio + video)
5. SDP offer created and sent via Socket.IO
6. Remote peer receives offer, creates answer
7. Answer sent back, connection established
8. ICE candidates exchanged for optimal routing
9. Remote video stream received and displayed

### Accepting an Incoming Call
1. Incoming call event received via Socket.IO
2. Call invitation modal displayed with caller name
3. User accepts call
4. Navigate to video call page
5. Same connection flow as initiating

### Ending a Call
1. User clicks end call button
2. Disconnect signal sent to remote peer
3. All media tracks stopped
4. Peer connection closed
5. Navigate back to home/messaging page

## Configuration

### STUN Servers
Default STUN servers for NAT traversal:
- `stun:stun.l.google.com:19302`
- `stun:stun1.l.google.com:19302`

Can be extended with TURN servers for relay in restrictive networks.

### Media Constraints
- Video: 1280x720 ideal resolution
- Audio: Echo cancellation and noise suppression enabled

## Browser Support
- Chrome/Chromium 74+
- Firefox 55+
- Safari 14.1+
- Edge 79+

All modern browsers with WebRTC and Socket.IO support.

## Future Enhancements
- Screen sharing capability
- Call recording
- Multi-party conferencing
- TURN server integration
- Call history persistence
- Ring tone/notification sounds
- Call statistics (latency, bandwidth)
